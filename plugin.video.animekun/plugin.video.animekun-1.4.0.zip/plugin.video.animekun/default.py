# coding=utf-8
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import urllib
import urllib2
import urlparse
from urllib2 import urlopen
from bs4 import BeautifulSoup
from bs4 import Tag
from bs4 import NavigableString
import html5lib
from t0mm0.common.net import Net
from t0mm0.common.addon import Addon
import re
import httplib2
import string
import json
import time
from base64 import b64encode

# plugin constants
__plugin__ = "plugin.video.animekun"
__version__ = "1.0.0"
__settings__ = xbmcaddon.Addon(id=__plugin__)
__addon_handle__ = int(sys.argv[1])
__base_url__ = sys.argv[0]
__media_url__ = 'special://home/addons/{0}/resources/art/'.format(__plugin__)
__profile__ = xbmc.translatePath( __settings__.getAddonInfo('profile')).decode('utf-8')
__addon__ = Addon(__plugin__, sys.argv)
net = Net(user_agent='Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.146 Safari/537.36')


xbmcplugin.setContent(__addon_handle__, 'movies')

def build_url(query):
	return __base_url__ + '?' + urllib.urlencode(query)

def main():
	url = build_url({'mode':'folder', 'foldername':'newOnSite'})
	li = xbmcgui.ListItem('Новое на сайте')
	xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)
	
	url = build_url({'mode':'folder', 'foldername':'anime'})
	li = xbmcgui.ListItem('Аниме')
	xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)

	url = build_url({'mode':'folder', 'foldername':'ongoing'})
	li = xbmcgui.ListItem('Онгоинги')
	xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)

	
	url = build_url({'mode':'folder', 'foldername':'genre'})
	li = xbmcgui.ListItem('Жанры')
	xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)

	url = build_url({'mode':'folder', 'foldername':'year'})
	li = xbmcgui.ListItem('Год')
	xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)
	
	url = build_url({'mode':'folder', 'foldername':'search'})
	li = xbmcgui.ListItem('Поиск')
	xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)
	
	url = build_url({'mode':'folder', 'foldername':'mal'})
	li = xbmcgui.ListItem('My Anime List')
	xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)
	
	xbmcplugin.endOfDirectory(__addon_handle__)
	pass

def getSubCategories(title):
	fetchURL = 'http://animekun.ru/'
	response = net.http_GET(fetchURL)
	soup = BeautifulSoup(response.content, 'html5lib')
	root = soup.find_all('a', text=title)[0]
	for subcat in root.parent.ul.children:
		if isinstance(subcat, Tag):
			url = build_url({'mode':'subfolder', 'path':httplib2.iri2uri(subcat.a['href'])})
			li = xbmcgui.ListItem(subcat.a.string)
			xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)
	
	xbmcplugin.endOfDirectory(__addon_handle__)
	pass

def getTitle(path):
	uri = 'http://animekun.ru' + path
	uri = uri.replace(' ', '%20')
	response = net.http_GET(uri)
	soup = BeautifulSoup(response.content, 'html5lib')
	titles = soup.select('span[itemprop=name]')
	for title in titles:
		url = build_url({'mode':'title', 'path':title.parent['href']})
		li = xbmcgui.ListItem(title.string)
		xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)
	
	xbmcplugin.endOfDirectory(__addon_handle__)
	pass

def getListing(url):
	uri = 'http://animekun.ru' + url
	uri = uri.replace(' ', '%20')
	response = net.http_GET(uri)
	soup = BeautifulSoup(response.content, 'html5lib')
	q = __addon__.get_setting('vk-quality')
	for row in soup.select('td.video_title'):
		title = row.string
		onclick = row['onclick']
		
		x = string.index(onclick, "'")
		y = string.index(onclick, "'", x + 1)
		url = onclick[x + 1:y]
		
		x = string.index(onclick, "'", y + 1)
		y = string.index(onclick, "'", x + 1)
		x = string.index(onclick, "'", y + 1)
		y = string.index(onclick, "'", x + 1)
		urlType = onclick[x + 1:y]
		if urlType == '5':#YouTube - pass
			continue
		
		
		#icon = __media_url__+'video-sibnet.png'
		if urlType == '1':
			#icon = __media_url__+'video-vkontakte.png'
			title = '(R) '+title
			li = xbmcgui.ListItem(title)
			playUrl = build_url({'mode':'play', 'path':url, 'title':title.encode('utf8'), 'type':urlType})
			xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)			
		elif urlType == '6':
			#icon = __media_url__+'video-rutube.png'
			if q == 'Show all':
				title = '(V) '+title
				li = xbmcgui.ListItem(title)
				playUrl = build_url({'mode':'showvk', 'path':url, 'title':title.encode('utf8'), 'type':urlType})
				xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=True)				
			else:
				title = '(V) '+title
				li = xbmcgui.ListItem(title)
				playUrl = build_url({'mode':'play', 'path':url, 'title':title.encode('utf8'), 'type':urlType})
				xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)				
		elif urlType == '7':
			#icon = __media_url__+'video-rutube.png'
			title = '(S) '+title
			li = xbmcgui.ListItem(title)
			playUrl = build_url({'mode':'play', 'path':url, 'title':title.encode('utf8'), 'type':urlType})
			xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)			
		elif urlType == '4':
			#icon = __media_url__+'video-rutube.png'
			title = '(K) '+title            
			li = xbmcgui.ListItem(title)
			playUrl = build_url({'mode':'play', 'path':url, 'title':title.encode('utf8'), 'type':urlType})
			xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)
		elif urlType == '3':
			#icon = __media_url__+'video-rutube.png'
			title = '(M) '+title            
			li = xbmcgui.ListItem(title)
			playUrl = build_url({'mode':'play', 'path':url, 'title':title.encode('utf8'), 'type':urlType})
			xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)
		else:
			title = '(?) '+title
			li = xbmcgui.ListItem(title)
			playUrl = build_url({'mode':'play', 'path':url, 'title':title.encode('utf8'), 'type':urlType})
			xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)
	
	xbmcplugin.endOfDirectory(__addon_handle__)
	pass

def showVKVideos(url, title):
	urlType = '6'
	response = net.http_GET(url)
	soup = BeautifulSoup(response.content, 'html5lib')
	fvars = soup.select('param[name=flashvars]')
	if len(fvars) == 0:
		return
	flashvars = fvars[0]['value']
	flashvars  = urlparse.parse_qs(flashvars)
	url720 = flashvars.get('url720', None)
	url480 = flashvars.get('url480', None)
	url360 = flashvars.get('url360', None)
	url240 = flashvars.get('url240', None)
	if (url720 != None):
		vtitle = title+'(720p)'
		li = xbmcgui.ListItem(vtitle)
		playUrl = build_url({'mode':'play', 'path':url, 'title':vtitle, 'type':urlType, 'quality':'720p'})
		xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)
	if (url480 != None):
		vtitle = title+'(480p)'
		li = xbmcgui.ListItem(vtitle)
		playUrl = build_url({'mode':'play', 'path':url, 'title':vtitle, 'type':urlType, 'quality':'480p'})
		xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)				
	if (url360 != None):
		vtitle = title+'(360p)'
		li = xbmcgui.ListItem(vtitle)
		playUrl = build_url({'mode':'play', 'path':url, 'title':vtitle, 'type':urlType, 'quality':'360p'})
		xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)				
	if (url240 != None):
		vtitle = title+'(240p)'
		li = xbmcgui.ListItem(vtitle)
		playUrl = build_url({'mode':'play', 'path':url, 'title':vtitle, 'type':urlType, 'quality':'240p'})
		xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)				
		
	xbmcplugin.endOfDirectory(__addon_handle__)
	
def play(url, title, type, quality=None):
	if type == '6':
		playVK(url, title, quality)
	elif type == '7':
		playSibnet(url, title)
	elif type == '1':
		playRuTube(url, title)
	elif type == '4':
		playKZ(url, title)
	elif type == '3':
		playMyvi(url, title)
		
	pass

def showOpenWindow(title):
	dialog = xbmcgui.DialogProgress()
	ret = dialog.create('Opening URL', 'Opening \''+title+'\'')
	# get window progress
	WINDOW_PROGRESS = xbmcgui.Window( 10101 )
	# give window time to initialize
	xbmc.sleep( 100 )
	# get our cancel button
	CANCEL_BUTTON = WINDOW_PROGRESS.getControl( 10 )
	# desable button (bool - True=enabled / False=disabled.)
	CANCEL_BUTTON.setEnabled( False )
	return dialog

def playMyvi(url, title):
	ret = showOpenWindow(title)
	li = xbmcgui.ListItem(label=title)
	li.setInfo(type='Video', infoLabels={ "Title": title})
	xbmc.Player().play(item=url, listitem=li)

	pass	
	
def playRuTube(url, title):
	ret = showOpenWindow(title)
	url = 'http://rutube.ru/api/play/trackinfo/{0}/?format=json'.format(url)
	response = net.http_GET(url)
	par = json.loads(response.content)
	m3u8 = par['video_balancer']['m3u8']
	li = xbmcgui.ListItem(label=title)
	li.setInfo(type='Video', infoLabels={ "Title": title})
	xbmc.Player().play(item=m3u8, listitem=li)

	pass

def playSibnet(url, title):
	ret = showOpenWindow(title)
	url = 'http://video.sibnet.ru/video' + url
	response = net.http_GET(url)
	soup = BeautifulSoup(response.content, 'html5lib')
	flashvars = soup.find_all('script', text=re.compile("jwplayer"))[0].string
	y = string.find(flashvars, '.mp4')
	x = string.rfind(flashvars, 'http', 0, y)
	url = flashvars[x:y+4]
	li = xbmcgui.ListItem(label=title)
	li.setInfo(type='Video', infoLabels={ "Title": title})
	xbmc.Player().play(item=url, listitem=li)
	pass

def playKZ(url, title):
	ret = showOpenWindow(title)
	url = 'http://kiwi.kz/watch/' + url
	response = net.http_GET(url)
	soup = BeautifulSoup(response.content, 'html5lib')
	flashvars = soup.select('param[name=movie]')[0]['value']
	x = flashvars.index('?')
	flashvars = flashvars[x+1:]
	url = urlparse.parse_qs(flashvars)['url'][0]
	li = xbmcgui.ListItem(label=title)
	li.setInfo(type='Video', infoLabels={ "Title": title})
	xbmc.Player().play(item=url, listitem=li)
	pass

def playVK(url, title, q):
	ret = showOpenWindow(title)
	if q is None:
		q =  __addon__.get_setting('vk-quality')
	response = net.http_GET(url)
	soup = BeautifulSoup(response.content, 'html5lib')
	fvars = soup.select('param[name=flashvars]')
	if len(fvars) == 0:
		__addon__.show_ok_dialog(['Эпизод \''+title+'\' был удален'], 'Error')
		return
	flashvars = fvars[0]['value']
	flashvars  = urlparse.parse_qs(flashvars)
	url720 = flashvars.get('url720', None)
	url480 = flashvars.get('url480', None)
	url360 = flashvars.get('url360', None)
	url240 = flashvars.get('url240', None)
	fileUrl = url720;
	if fileUrl is None or q == '480p':
		fileUrl = url480;
		
	if fileUrl is None or q == '360p':
		fileUrl = url360;
			
	if fileUrl is None or q == '240p':
		fileUrl = url240;     
	
	fileUrl = fileUrl[0]
	li = xbmcgui.ListItem(label=title)
	li.setInfo(type='Video', infoLabels={ "Title": title})
	xbmc.Player().play(item=fileUrl, listitem=li)
	pass


def newOnSite():
	getTitle('/')
	pass

def anime():
	getSubCategories('Аниме')
	pass

def ongoing():
	getSubCategories('Онгоинги')
	pass

def year():
	getSubCategories('ГОД')
	pass

def genre():
	getSubCategories('ЖАНРЫ')
	pass

def search():
	kb = xbmc.Keyboard('', 'Search Animekun', False)
	kb.doModal()
	if (kb.isConfirmed()):
		search = kb.getText()
		if search != '':
			getTitle('/search/' + search + '/') 
	pass

def mal ():
	user =  __addon__.get_setting('mal-user')
	epoch_time = int(time.time())
	titlesURL = "http://myanimelist.net/animelist/"+user
	userAndPass = b64encode(b"bikedreamer:rzbavigar").decode("ascii")
	headers= {"Connection": "keep-alive",
	"Authorization": 'Basic %s' %  userAndPass,
	"Cache-Control": "no-cache",
	"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
	"Pragma": "no-cache",
	"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.146 Safari/537.36",
	"Accept-Language": "en-US,en;q=0.8,ru;q=0.6",
	"Cookie": "gn_country=US; visitor_country=US; __gads=ID=cb6e524bdb98db9c:T="+str(epoch_time)+":S=ALNI_MbAvYkMt1DMsbJSspz4U5D4K_5Hqw; incap_ses_124_81958=9tsdMiyqMRKuCyKjToq4Adb5IVMAAAAAjaka4SW86K7LRUgTLL/EWg==; incap_ses_225_81958=a8/TISn62WSNaSwmWFwfAxr6IVMAAAAAtqlnQhuAhzL9cqoVVB5YYg==; visid_incap_81958=6V5/85OvRm2CHFffsy4SwN7xIVMAAAAAQkIPAAAAAACAGrNiAdhxqIdSB0rbzXik/72K8Fzb45cd; __utma=242346526.1905294727."+str(epoch_time)+"."+str(epoch_time)+"."+str(epoch_time)+".2; __utmc=242346526; __utmz=242346526.1394733538.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)"}
	response = net.http_GET(titlesURL, headers)
	print '----------->'
	print response.content
	soup = BeautifulSoup(response.content)
	s = soup.find('table', class_='header_cw')
	addMALItems(s)
	
	s = soup.find('table', class_='header_ptw')
	addMALItems(s)
	
	xbmcplugin.endOfDirectory(__addon_handle__)
	pass
def addMALItems(s):
	c = s.find_next_sibling()
	while True:
		c = c.find_next_sibling()
		if c.name != 'table':
			continue
		
		tr = c.find('tr')			
		tds = tr.find_all('td')
		if len(tds)<2:
			break
			
		ah =tds[1].find('a', class_='animetitle')
		if ah is None:
			break
				
		if tds[5].find('span').find('a') is None or 'animekun' not in tds[5].find('span').find('a').getText():
			continue
		
		title =ah.find('span').getText();
		path = None
		if tds[5].find('span').find('a') is not None:
			path = tds[5].find('span').find('a').getText()
		
		path = path.replace('http://animekun.ru','')
		url = build_url({'mode':'title', 'path':path})
		li = xbmcgui.ListItem(title)
		xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)
	
if __name__ == "__main__":
	args = urlparse.parse_qs(sys.argv[2][1:])
	mode = args.get('mode', None)
	
	if mode is None:
		main()
	elif mode[0] == 'folder':
		fn = args.get('foldername')[0]
		if fn == 'newOnSite':
			newOnSite()
		elif fn == 'anime':
			anime()
		elif fn == 'ongoing':
			ongoing()
		elif fn == 'genre':
			genre()
		elif fn == 'year':
			year()
		elif fn == 'search':
			search()
		elif fn == 'mal':
			mal()			
	elif mode[0] == 'subfolder':
		getTitle(args.get('path', '/')[0])
	elif mode[0] == 'title':
		getListing(args.get('path', '/')[0])
	elif mode[0] == 'showvk':
		showVKVideos(args.get('path', '/')[0], args.get('title', 'Title')[0])		
	elif mode[0] == 'play':
		q = args.get('quality', None)
		if q != None:
			q = q[0]
		play(args.get('path', '/')[0], args.get('title', 'Title')[0], args.get('type', '0')[0], q)

sys.modules.clear()
