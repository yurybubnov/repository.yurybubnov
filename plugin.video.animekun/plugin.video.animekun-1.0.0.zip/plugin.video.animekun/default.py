# coding=utf-8
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import urllib
import urllib2
import urlparse
from urllib2 import urlopen
from bs4 import BeautifulSoup
from bs4 import Tag
from bs4 import NavigableString
import html5lib
from t0mm0.common.net import Net
from t0mm0.common.addon import Addon
import re
import httplib2
import string
import json

# plugin constants
__plugin__ = "plugin.video.animekun"
__version__ = "1.0.0"
__settings__ = xbmcaddon.Addon(id=__plugin__)
__addon_handle__ = int(sys.argv[1])
__base_url__ = sys.argv[0]
__media_url__ = 'special://home/addons/{0}/resources/art/'.format(__plugin__)
__profile__ = xbmc.translatePath( __settings__.getAddonInfo('profile')).decode('utf-8')
__addon__ = Addon(__plugin__, sys.argv)
net = Net()


xbmcplugin.setContent(__addon_handle__, 'movies')

def build_url(query):
    return __base_url__ + '?' + urllib.urlencode(query)

def main():
    url = build_url({'mode':'folder', 'foldername':'newOnSite'})
    li = xbmcgui.ListItem('Новое на сайте')
    xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)
    
    url = build_url({'mode':'folder', 'foldername':'anime'})
    li = xbmcgui.ListItem('Аниме')
    xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)

    url = build_url({'mode':'folder', 'foldername':'ongoing'})
    li = xbmcgui.ListItem('Онгоинги')
    xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)

    
    url = build_url({'mode':'folder', 'foldername':'genre'})
    li = xbmcgui.ListItem('Жанры')
    xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)

    url = build_url({'mode':'folder', 'foldername':'year'})
    li = xbmcgui.ListItem('Год')
    xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)
    
    url = build_url({'mode':'folder', 'foldername':'search'})
    li = xbmcgui.ListItem('Поиск')
    xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)
    
    xbmcplugin.endOfDirectory(__addon_handle__)
    pass

def getSubCategories(title):
    fetchURL = 'http://animekun.ru/'
    response = net.http_GET(fetchURL)
    soup = BeautifulSoup(response.content, 'html5lib')
    root = soup.find_all('a', text=title)[0]
    for subcat in root.parent.ul.children:
        if isinstance(subcat, Tag):
            url = build_url({'mode':'subfolder', 'path':httplib2.iri2uri(subcat.a['href'])})
            li = xbmcgui.ListItem(subcat.a.string)
            xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)
    
    xbmcplugin.endOfDirectory(__addon_handle__)
    pass

def getTitle(path):
    uri = 'http://animekun.ru' + path
    uri = uri.replace(' ', '%20')
    response = net.http_GET(uri)
    soup = BeautifulSoup(response.content, 'html5lib')
    titles = soup.select('span[itemprop=name]')
    for title in titles:
        url = build_url({'mode':'title', 'path':title.parent['href']})
        li = xbmcgui.ListItem(title.string)
        xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)
    
    xbmcplugin.endOfDirectory(__addon_handle__)
    pass

def getListing(url):
    uri = 'http://animekun.ru' + url
    uri = uri.replace(' ', '%20')
    response = net.http_GET(uri)
    soup = BeautifulSoup(response.content, 'html5lib')
    for row in soup.select('td.video_title'):
        title = row.string
        url = row['onclick']
        
        x = string.index(url, "'")
        y = string.index(url, "'", x + 1)
        url = url[x + 1:y]
        if ('_Y' in url) or ('myvi.ru' in url):
            continue
        url = build_url({'mode':'play', 'path':url, 'title':title.encode('utf8')})
        
        icon = __media_url__+'video-sibnet.png'
        if 'vk.com' in url:
            icon = __media_url__+'video-vkontakte.png'
            title = '(V) '+title
        elif not url.isdigit():
            icon = __media_url__+'video-rutube.png'
            title = '(R) '+title
        else:
            title = '(S) '+title
        li = xbmcgui.ListItem(title, iconImage=icon, thumbnailImage=icon)
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=False)
    
    xbmcplugin.endOfDirectory(__addon_handle__)
    pass

def play(url, title):
    if 'vk.com' in url:
        playVK(url, title)
    elif url.isdigit():
        playSibnet(url, title)
    else:
        playRuTube(url, title)
    pass

def playRuTube(url, title):
    url = 'http://rutube.ru/api/play/trackinfo/{0}/?format=json'.format(url)
    response = net.http_GET(url)
    par = json.loads(response.content)
    m3u8 = par['video_balancer']['m3u8']
    li = xbmcgui.ListItem(label=title)
    li.setInfo(type='Video', infoLabels={ "Title": title})
    xbmc.Player().play(item=m3u8, listitem=li)

    pass

def playSibnet(url, title):
    url = 'http://video.sibnet.ru/video' + url
    response = net.http_GET(url)
    soup = BeautifulSoup(response.content, 'html5lib')
    flashvars = soup.find_all('script', text=re.compile("jwplayer"))[0].string
    y = string.find(flashvars, '.mp4')
    x = string.rfind(flashvars, 'http', 0, y)
    url = flashvars[x:y+4]
    li = xbmcgui.ListItem(label=title)
    li.setInfo(type='Video', infoLabels={ "Title": title})
    xbmc.Player().play(item=url, listitem=li)
    pass

def playVK(url, title):
    response = net.http_GET(url)
    soup = BeautifulSoup(response.content, 'html5lib')
    fvars = soup.select('param[name=flashvars]')
    if len(fvars) == 0:
        __addon__.show_ok_dialog(['Эпизод \''+title+'\' был удален'], 'Error')
        return
    flashvars = fvars[0]['value']
    flashvars  = urlparse.parse_qs(flashvars)
    url720 = flashvars.get('url720', None)
    url480 = flashvars.get('url480', None)
    url360 = flashvars.get('url360', None)
    url240 = flashvars.get('url240', None)
    fileUrl = url720;
    
    if fileUrl is None:
        fileUrl = url480;
         
    if fileUrl is None:
        fileUrl = url360;
         
    if fileUrl is None:
        fileUrl = url240;     

    fileUrl = fileUrl[0]
    li = xbmcgui.ListItem(label=title)
    li.setInfo(type='Video', infoLabels={ "Title": title})
    xbmc.Player().play(item=fileUrl, listitem=li)
    pass


def newOnSite():
    getTitle('/')
    pass

def anime():
    getSubCategories('Аниме')
    pass

def ongoing():
    getSubCategories('Онгоинги')
    pass

def year():
    getSubCategories('ГОД')
    pass

def genre():
    getSubCategories('ЖАНРЫ')
    pass

def search():
    kb = xbmc.Keyboard('', 'Search Animekun', False)
    kb.doModal()
    if (kb.isConfirmed()):
        search = kb.getText()
        if search != '':
            getTitle('/search/' + search + '/') 
    pass


if __name__ == "__main__":
    args = urlparse.parse_qs(sys.argv[2][1:])
    mode = args.get('mode', None)
    
    if mode is None:
        main()
    elif mode[0] == 'folder':
        fn = args.get('foldername')[0]
        if fn == 'newOnSite':
            newOnSite()
        elif fn == 'anime':
            anime()
        elif fn == 'ongoing':
            ongoing()
        elif fn == 'genre':
            genre()
        elif fn == 'year':
            year()
        elif fn == 'search':
            search()
    elif mode[0] == 'subfolder':
        getTitle(args.get('path', '/')[0])
    elif mode[0] == 'title':
        getListing(args.get('path', '/')[0])
    elif mode[0] == 'play':
        play(args.get('path', '/')[0], args.get('title', 'Title')[0])

sys.modules.clear()
