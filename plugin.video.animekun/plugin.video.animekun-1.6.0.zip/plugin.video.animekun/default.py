# coding=utf-8
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import urllib
import urllib2
import urlparse
from urllib2 import urlopen
from bs4 import BeautifulSoup
from bs4 import Tag
from bs4 import NavigableString
import html5lib
from t0mm0.common.net import Net
from t0mm0.common.addon import Addon
import re
import httplib2
import string
import json
import time
from base64 import b64encode
import urlresolver

# plugin constants
__plugin__ = "plugin.video.animekun"
__version__ = "1.0.0"
__settings__ = xbmcaddon.Addon(id=__plugin__)
__addon_handle__ = int(sys.argv[1])
__base_url__ = sys.argv[0]
__media_url__ = 'special://home/addons/{0}/resources/art/'.format(__plugin__)
__profile__ = xbmc.translatePath( __settings__.getAddonInfo('profile')).decode('utf-8')
__addon__ = Addon(__plugin__, sys.argv)
net = Net(user_agent='Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.146 Safari/537.36')


xbmcplugin.setContent(__addon_handle__, 'movies')

def build_url(query):
	return __base_url__ + '?' + urllib.urlencode(query)

def main():
	url = build_url({'mode':'folder', 'foldername':'newOnSite'})
	li = xbmcgui.ListItem('Новое на сайте')
	xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)
	
	url = build_url({'mode':'folder', 'foldername':'anime'})
	li = xbmcgui.ListItem('Аниме')
	xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)

	url = build_url({'mode':'folder', 'foldername':'ongoing'})
	li = xbmcgui.ListItem('Онгоинги')
	xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)

	
	url = build_url({'mode':'folder', 'foldername':'genre'})
	li = xbmcgui.ListItem('Жанры')
	xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)

	url = build_url({'mode':'folder', 'foldername':'year'})
	li = xbmcgui.ListItem('Год')
	xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)
	
	url = build_url({'mode':'folder', 'foldername':'search'})
	li = xbmcgui.ListItem('Поиск')
	xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)
	
	url = build_url({'mode':'folder', 'foldername':'mal'})
	li = xbmcgui.ListItem('My Anime List')
	xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)
	
	xbmcplugin.endOfDirectory(__addon_handle__)
	pass

def getSubCategories(title):
	fetchURL = 'http://animekun.ru/'
	response = net.http_GET(fetchURL)
	soup = BeautifulSoup(response.content, 'html5lib')
	root = soup.find_all('a', text=title)[0]
	for subcat in root.parent.ul.children:
		if isinstance(subcat, Tag):
			url = build_url({'mode':'subfolder', 'path':httplib2.iri2uri(subcat.a['href'])})
			li = xbmcgui.ListItem(subcat.a.string)
			xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)
	
	xbmcplugin.endOfDirectory(__addon_handle__)
	pass

def getTitle(path):
	uri = 'http://animekun.ru' + path
	uri = uri.replace(' ', '%20')
	response = net.http_GET(uri)
	soup = BeautifulSoup(response.content, 'html5lib')
	titles = soup.select('span[itemprop=name]')
	for title in titles:
		pp = title.parent.parent
		imdiv = pp.find_next_sibling('div', class_='page_image_item')
		image=''
		if imdiv is not None:
			img = imdiv.find('img')
			if img is not None:
				image = img['src']
		url = build_url({'mode':'title', 'path':title.parent['href']})
		li = xbmcgui.ListItem(label=title.string, iconImage=image)
		xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)
	
	nextPage(soup)
	
	xbmcplugin.endOfDirectory(__addon_handle__)
	pass

def getListing(url):
	uri = 'http://animekun.ru' + url
	uri = uri.replace(' ', '%20')
	response = net.http_GET(uri)
	soup = BeautifulSoup(response.content, 'html5lib')
	q = __addon__.get_setting('vk-quality')
	for row in soup.select('td.video_title'):
		title = row.string
		onclick = row['onclick']
		
		x = string.index(onclick, "'")
		y = string.index(onclick, "'", x + 1)
		url = onclick[x + 1:y]
		
		x = string.index(onclick, "'", y + 1)
		y = string.index(onclick, "'", x + 1)
		x = string.index(onclick, "'", y + 1)
		y = string.index(onclick, "'", x + 1)
		urlType = onclick[x + 1:y]		
		
		#icon = __media_url__+'video-sibnet.png'
		if urlType == '1':
			#icon = __media_url__+'video-vkontakte.png'
			title = '(R) '+title
			li = xbmcgui.ListItem(title)
			playUrl = build_url({'mode':'play', 'path':url, 'title':title.encode('utf8'), 'type':urlType})
			xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)			
		elif urlType == '6':
			#icon = __media_url__+'video-rutube.png'
			if q == 'Show all':
				title = '(V) '+title
				li = xbmcgui.ListItem(title)
				playUrl = build_url({'mode':'showvk', 'path':url, 'title':title.encode('utf8'), 'type':urlType})
				xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=True)				
			else:
				title = '(V) '+title
				li = xbmcgui.ListItem(title)
				playUrl = build_url({'mode':'play', 'path':url, 'title':title.encode('utf8'), 'type':urlType})
				xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)				
		elif urlType == '7':
			#icon = __media_url__+'video-rutube.png'
			title = '(S) '+title
			li = xbmcgui.ListItem(title)
			playUrl = build_url({'mode':'play', 'path':url, 'title':title.encode('utf8'), 'type':urlType})
			xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)			
		elif urlType == '25':
			#icon = __media_url__+'video-rutube.png'
			title = '(A) '+title
			li = xbmcgui.ListItem(title)
			playUrl = build_url({'mode':'play', 'path':url, 'title':title.encode('utf8'), 'type':urlType})
			xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)						
		elif urlType == '4':
			#icon = __media_url__+'video-rutube.png'
			title = '(K) '+title            
			li = xbmcgui.ListItem(title)
			playUrl = build_url({'mode':'play', 'path':url, 'title':title.encode('utf8'), 'type':urlType})
			xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)
		elif urlType == '3':
			#icon = __media_url__+'video-rutube.png'
			title = '(M) '+title            
			li = xbmcgui.ListItem(title)
			playUrl = build_url({'mode':'play', 'path':url, 'title':title.encode('utf8'), 'type':urlType})
			xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)
		elif urlType == '5':
			#icon = __media_url__+'video-rutube.png'
			title = '(Y) '+title            
			li = xbmcgui.ListItem(title)
			li.setProperty("IsPlayable", "true")
			media_url = urlresolver.resolve('http://youtu.be/'+url) 
			playUrl = build_url({'mode':'play', 'path':url, 'title':title.encode('utf8'), 'type':urlType})
			xbmcplugin.addDirectoryItem(__addon_handle__, media_url, li, isFolder=False)			
		
		else:
			title = '(?) '+title
			li = xbmcgui.ListItem(title)
			playUrl = build_url({'mode':'play', 'path':url, 'title':title.encode('utf8'), 'type':urlType})
			xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)
	
	xbmcplugin.endOfDirectory(__addon_handle__)
	pass

def showVKVideos(url, title):
	urlType = '6'
	response = net.http_GET(url)
	soup = BeautifulSoup(response.content, 'html5lib')
	fvars = soup.select('param[name=flashvars]')
	if len(fvars) == 0:
		return
	flashvars = fvars[0]['value']
	flashvars  = urlparse.parse_qs(flashvars)
	url720 = flashvars.get('url720', None)
	url480 = flashvars.get('url480', None)
	url360 = flashvars.get('url360', None)
	url240 = flashvars.get('url240', None)
	if (url720 != None):
		vtitle = title+'(720p)'
		li = xbmcgui.ListItem(vtitle)
		playUrl = build_url({'mode':'play', 'path':url, 'title':vtitle, 'type':urlType, 'quality':'720p'})
		xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)
	if (url480 != None):
		vtitle = title+'(480p)'
		li = xbmcgui.ListItem(vtitle)
		playUrl = build_url({'mode':'play', 'path':url, 'title':vtitle, 'type':urlType, 'quality':'480p'})
		xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)				
	if (url360 != None):
		vtitle = title+'(360p)'
		li = xbmcgui.ListItem(vtitle)
		playUrl = build_url({'mode':'play', 'path':url, 'title':vtitle, 'type':urlType, 'quality':'360p'})
		xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)				
	if (url240 != None):
		vtitle = title+'(240p)'
		li = xbmcgui.ListItem(vtitle)
		playUrl = build_url({'mode':'play', 'path':url, 'title':vtitle, 'type':urlType, 'quality':'240p'})
		xbmcplugin.addDirectoryItem(__addon_handle__, playUrl, li, isFolder=False)				
		
	xbmcplugin.endOfDirectory(__addon_handle__)
	
def play(url, title, type, quality=None):
	if type == '6':
		playVK(url, title, quality)
	elif type == '7':
		playSibnet(url, title)
	elif type == '1':
		playRuTube(url, title)
	elif type == '4':
		playKZ(url, title)
	elif type == '3':
		playMyvi(url, title)
	elif type == '25':
		playAMV(url, title)
	elif type == '5':
		playYouTube(url, title)
		
	pass

def showOpenWindow(title):
	dialog = xbmcgui.DialogProgress()
	ret = dialog.create('Opening URL', 'Opening \''+title+'\'')
	# get window progress
	WINDOW_PROGRESS = xbmcgui.Window( 10101 )
	# give window time to initialize
	xbmc.sleep( 100 )
	# get our cancel button
	CANCEL_BUTTON = WINDOW_PROGRESS.getControl( 10 )
	# desable button (bool - True=enabled / False=disabled.)
	CANCEL_BUTTON.setEnabled( False )
	return dialog

def playYouTube(url, title):
	ret = showOpenWindow(title)
	media_url = urlresolver.resolve('http://youtu.be/'+url) 
	xbmc.executebuiltin("xbmc.PlayMedia("+media_url+")")
	#li = xbmcgui.ListItem(label=title)
	#li.setInfo(type='Video', infoLabels={ "Title": title})
	#xbmc.Player().play(item=url, listitem=li)

	pass		
	
def playMyvi(url, title):
	ret = showOpenWindow(title)
	li = xbmcgui.ListItem(label=title)
	li.setInfo(type='Video', infoLabels={ "Title": title})
	xbmc.Player().play(item=url, listitem=li)

	pass	
	
def playRuTube(url, title):
	ret = showOpenWindow(title)
	url = 'http://rutube.ru/api/play/trackinfo/{0}/?format=json'.format(url)
	response = net.http_GET(url)
	par = json.loads(response.content)
	m3u8 = par['video_balancer']['m3u8']
	li = xbmcgui.ListItem(label=title)
	li.setInfo(type='Video', infoLabels={ "Title": title})
	xbmc.Player().play(item=m3u8, listitem=li)

	pass

def playSibnet(url, title):
	ret = showOpenWindow(title)
	url = 'http://video.sibnet.ru/video' + url
	response = net.http_GET(url)
	
	soup = BeautifulSoup(response.content, 'html5lib')
	flashvars = soup.find_all('script', text=re.compile("jwplayer"))[0].string
	x = string.find(flashvars, "'file':'")
	y = string.find(flashvars, "'", x+8)
	url = flashvars[x+8:y]
	li = xbmcgui.ListItem(label=title)
	li.setInfo(type='Video', infoLabels={ "Title": title})
	xbmc.Player().play(item=url, listitem=li)
	pass

def playAMV(url, title):
	ret = showOpenWindow(title)
	url = 'http://amvnews.ru/index.php?go=Files&file=se&hd=1&id='+url
	response = net.http_GET(url)
	soup = BeautifulSoup(response.content, 'html5lib')
	tag = soup.find('jwplayer:hd.file')
	if tag is None:
		tag = soup.find('jwplayer:file')
		
	url = tag.string
	li = xbmcgui.ListItem(label=title)
	li.setInfo(type='Video', infoLabels={ "Title": title})
	xbmc.Player().play(item=url, listitem=li)
	pass	
	
def playKZ(url, title):
	ret = showOpenWindow(title)
	url = 'http://kiwi.kz/watch/' + url
	response = net.http_GET(url)
	soup = BeautifulSoup(response.content, 'html5lib')
	flashvars = soup.select('param[name=movie]')[0]['value']
	x = flashvars.index('?')
	flashvars = flashvars[x+1:]
	url = urlparse.parse_qs(flashvars)['url'][0]
	li = xbmcgui.ListItem(label=title)
	li.setInfo(type='Video', infoLabels={ "Title": title})
	xbmc.Player().play(item=url, listitem=li)
	pass

def playVK(url, title, q):
	ret = showOpenWindow(title)
	if q is None:
		q =  __addon__.get_setting('vk-quality')
	response = net.http_GET(url)
	soup = BeautifulSoup(response.content, 'html5lib')
	fvars = soup.select('param[name=flashvars]')
	if len(fvars) == 0:
		__addon__.show_ok_dialog(['Эпизод \''+title+'\' был удален'], 'Error')
		return
	flashvars = fvars[0]['value']
	flashvars  = urlparse.parse_qs(flashvars)
	url720 = flashvars.get('url720', None)
	url480 = flashvars.get('url480', None)
	url360 = flashvars.get('url360', None)
	url240 = flashvars.get('url240', None)
	fileUrl = url720;
	if fileUrl is None or q == '480p':
		fileUrl = url480;
		
	if fileUrl is None or q == '360p':
		fileUrl = url360;
			
	if fileUrl is None or q == '240p':
		fileUrl = url240;     
	
	fileUrl = fileUrl[0]
	li = xbmcgui.ListItem(label=title)
	li.setInfo(type='Video', infoLabels={ "Title": title})
	xbmc.Player().play(item=fileUrl, listitem=li)
	pass


def newOnSite():
	getTitle('/')
	pass

def anime():
	getSubCategories('Аниме')
	pass

def ongoing():
	getSubCategories('Онгоинги')
	pass

def year():
	getSubCategories('ГОД')
	pass

def genre():
	getSubCategories('ЖАНРЫ')
	pass

def search():
	kb = xbmc.Keyboard('', 'Search Animekun', False)
	kb.doModal()
	if (kb.isConfirmed()):
		search = kb.getText()
		if search != '':
			getTitle('/search/' + search + '/') 
	pass	
	
def mal ():
	user =  __addon__.get_setting('mal-user')
	epoch_time = int(time.time())
	titlesURL = "http://myanimelist.net/malappinfo.php?status=all&type=anime&u="+user
	headers= {"User-Agent": "api-indiv-9747F55953AAD22C307D0495C1524839",}
	response = net.http_GET(titlesURL, headers)
	soup = BeautifulSoup(response.content)
	s = soup.find_all('my_status', text='1')
	addMALItems(s)
	
	s = soup.find_all('my_status', text='6')
	addMALItems(s)
	
	xbmcplugin.endOfDirectory(__addon_handle__)
	pass
def addMALItems(statuses):
	if statuses is None:
		return
	for status in statuses:
		anime = status.parent
		image = anime.series_image.string if anime.series_image is not None else ''
		title = anime.series_title.string
		path = anime.my_tags.string if anime.my_tags is not None else ''
		if path is None or 'animekun' not in path:
			continue
		path = path.replace('http://animekun.ru','')
		url = build_url({'mode':'title', 'path':path})
		li = xbmcgui.ListItem(label=title, iconImage=image)
		xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)

def nextPage(soup):
	npd = soup.find('div', class_='wp-pagenavi')
	if npd is None:
		return
	current = npd.find('span', class_='current')
	if current is None:
		return
	next = current.find_next_sibling('a')
	if next is None:
		return
	title = next['title']
	path = next['href']
	path = path.replace('http://animekun.ru','')
	url = build_url({'mode':'subfolder', 'path':path})
	li = xbmcgui.ListItem(label=title)
	xbmcplugin.addDirectoryItem(__addon_handle__, url, li, isFolder=True)
	pass
		
if __name__ == "__main__":
	args = urlparse.parse_qs(sys.argv[2][1:])
	mode = args.get('mode', None)
	
	if mode is None:
		main()
	elif mode[0] == 'folder':
		fn = args.get('foldername')[0]
		if fn == 'newOnSite':
			newOnSite()
		elif fn == 'anime':
			anime()
		elif fn == 'ongoing':
			ongoing()
		elif fn == 'genre':
			genre()
		elif fn == 'year':
			year()
		elif fn == 'search':
			search()
		elif fn == 'mal':
			mal()			
	elif mode[0] == 'subfolder':
		getTitle(args.get('path', '/')[0])
	elif mode[0] == 'title':
		getListing(args.get('path', '/')[0])
	elif mode[0] == 'showvk':
		showVKVideos(args.get('path', '/')[0], args.get('title', 'Title')[0])		
	elif mode[0] == 'play':
		q = args.get('quality', None)
		if q != None:
			q = q[0]
		play(args.get('path', '/')[0], args.get('title', 'Title')[0], args.get('type', '0')[0], q)

sys.modules.clear()
